import type { DifficultyLevel, QuestionItem, QuestionType } from "@/components/question-bank/types";

export type SlotType = "Trắc nghiệm" | "Đúng/Sai" | "Trả lời ngắn" | "Tự luận";
export const SLOT_TYPES: SlotType[] = ["Trắc nghiệm", "Đúng/Sai", "Trả lời ngắn", "Tự luận"];

export interface MatrixRow {
  id: string;
  type: SlotType;
  /** id mục trên cây mục lục (dạng bài); null = chưa chọn */
  topicId: string | null;
  /** null = chưa chọn mức ("Mức?") */
  level: DifficultyLevel | null;
  /** câu hỏi đã chọn cho dòng này */
  questionId: string | null;
}

export type Counts = Record<SlotType, number>;

/** Cấu trúc đề tham khảo THPT QG (Toán): 12 TN + 4 Đúng/Sai + 6 Trả lời ngắn = 22 câu */
export const THPTQG: Counts = { "Trắc nghiệm": 12, "Đúng/Sai": 4, "Trả lời ngắn": 6, "Tự luận": 0 };

export interface SavedMatrix {
  id: string;
  name: string;
  savedAt: string;
  rows: MatrixRow[];
}

export const normType = (t: QuestionType): SlotType => (t === "Đúng sai" ? "Đúng/Sai" : t);

// id dòng chỉ cần duy nhất trong phiên làm việc (dùng bộ đếm, không dùng Date/Math.random để tương thích prerender).
// Mọi dòng đọc từ localStorage / kho / file đều được cấp id mới bằng hàm này.
let seq = 0;
export const newRowId = () => `r${seq++}`;

export const blankRow = (type: SlotType): MatrixRow => ({ id: newRowId(), type, topicId: null, level: null, questionId: null });

/** Dựng danh sách dòng theo số lượng từng kiểu, giữ lại các dòng cũ (theo thứ tự) nếu còn chỗ. */
export function makeRows(counts: Counts, prev: MatrixRow[] = []): MatrixRow[] {
  const out: MatrixRow[] = [];
  for (const t of SLOT_TYPES) {
    const old = prev.filter((r) => r.type === t);
    for (let i = 0; i < counts[t]; i++) out.push(old[i] ?? blankRow(t));
  }
  return out;
}

export function countRows(rows: MatrixRow[]): Counts {
  const c: Counts = { "Trắc nghiệm": 0, "Đúng/Sai": 0, "Trả lời ngắn": 0, "Tự luận": 0 };
  rows.forEach((r) => c[r.type]++);
  return c;
}

export const effectiveLevel = (row: MatrixRow, q?: QuestionItem): DifficultyLevel | null => row.level ?? q?.level ?? null;
